#!/system/bin/sh

${0%/*}/start.sh check
exit 0