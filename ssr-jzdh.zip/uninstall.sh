#!/bin/bash
export PATH="/bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin:/usr/local/sbin"
wp="/usr/local/ssr-jzdh"

systemctl disable ssr.service
systemctl kill ssr.service
systemctl disable koolproxy.service
systemctl kill koolproxy.service

iptables -t nat -D OUTPUT -p tcp -m ttl --ttl-eq 160 -j ACCEPT
iptables -t nat -D OUTPUT -p tcp --dport 80 -j REDIRECT --to 3000

rm -rf $wp
rm -f /etc/systemd/system/ssr.service
rm -f /etc/systemd/system/koolproxy.service
rm -f /bin/ssr

sed -i '/ssr_update\.sh/d' /etc/crontab