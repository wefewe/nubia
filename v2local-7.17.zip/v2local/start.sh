#!/system/bin/sh

jzdh=$1 && wp=${0%/*}

v2local_check() {
    echo
    v2ray_status="    ○⊃ V2Ray" && [ ! -z "$(pgrep v2ray)" ] && v2ray_status="    ⊂● V2Ray"
    pdnsd_status="   ○⊃ pdnsd" && [ ! -z "$(pgrep pdnsd)" ] && pdnsd_status="   ⊂● pdnsd"
    [ "$udp_proxy" = "on" ] && Redsocks2_status="   ○⊃ Redsocks2"
    [ ! -z "$(pgrep redsocks2)" ] && Redsocks2_status="   ⊂● Redsocks2"
    echo "${v2ray_status} ${pdnsd_status} ${Redsocks2_status}"
    if [ ! -z "${app_direct}" ];then
        echo
        for X in ${app_direct};do
            app_info=$(grep "$X " /data/system/packages.list)
            F=$(echo "$app_info" | awk '{print $2}')
            X=$(echo "$app_info" | awk '{print $1}')
            [ -z "$F" ] || echo "    ${F} ${X}"
        done
        echo
    fi
}

v2local_stop() {
    killall v2ray pdnsd redsocks2
    ip route flush cache
    ip rule del fwmark 0x33772 table 121
    ip route del local 0.0.0.0/0 dev lo table 121
    iptables -t nat -F VNO
    iptables -t nat -F VNP
    iptables -t mangle -F VMO
    iptables -t mangle -F VMP
    iptables -t nat -D OUTPUT -j VNO
    iptables -t nat -D PREROUTING -j VNP
    iptables -t mangle -D OUTPUT -j VMO
    iptables -t mangle -D PREROUTING -j VMP
    iptables -t nat -X VNO
    iptables -t nat -X VNP
    iptables -t mangle -X VMO
    iptables -t mangle -X VMP
} > /dev/null 2>&1

pre_v2local() {
    cd $wp && source $(pwd)/v2ray.ini
    export PATH=${PATH}:$(pwd)/bin
    pdnsd --help > /dev/null 2>&1
    [ "$?" = "126" ] && echo && echo "  请赋予文件夹及其子文件777权限" && exit 0
    wp_if_system=$(echo "$(pwd)" | busybox grep -Eo "^/system|^/etc")
    [ -z "$wp_if_system" ] || busybox mount -o remount,rw /system
    for C in awk echo grep sed killall ip ifconfig chmod rm pgrep nohup sleep chpst;do
        busybox ln -s $(pwd)/bin/busybox $(pwd)/bin/${C} > /dev/null 2>&1
    done
    special_ip='10.0.0.172/32,10.0.0.200/32,0/8,10/8,127/8,192.168/16,255.255/8,240/4,224/3,169.254/16,100.64/10,172.16/12'
    rm -f $(pwd)/*.bak
    rm -f $(pwd)/*/*.bak
    chmod -R 777 $(pwd)
}

vim_config() {
    UUID=$(echo "$v2ray" | awk '{print $2}')
    address=$(echo "$v2ray" | awk '{print $1}')
    for E in config.json break_copyright.json;do
        sed -i 's|address.*|address": "'$address'",|g' $(pwd)/bin/${E}
        sed -i 's|^          "port.*|          "port": '$port',|g' $(pwd)/bin/${E}
        sed -i 's|"id".*|"id": "'$UUID'",|g' $(pwd)/bin/${E}
        sed -i 's|"alterId".*|"alterId": '$alterId',|g' $(pwd)/bin/${E}
        sed -i 's|"security".*|"security": "'$security'"|g' $(pwd)/bin/${E}
        sed -i 's|"path": \[".*"\]|"path": \["'$Path'"\]|g' $(pwd)/bin/${E}
        sed -i 's|"Host": \[".*"\]|"Host": \["'$Host'"\]|g' $(pwd)/bin/${E}
    done
    sed -i 's|.* ip.*|    ip = '$DNS_ip'\;|' $(pwd)/bin/pdnsd.conf
    sed -i 's|cache_dir.*|cache_dir = "'$(pwd)/bin'"\;|' $(pwd)/bin/pdnsd.conf
}

v2local_bin_start() {
    v2ray_path=$(pwd | sed 's|/| /|g')
    for C in ${v2ray_path};do
        X="${X}$C"
        chmod_bak_r=$(ls -dl $X | awk '{print $1}' | sed 's|.*\(...\)$|\1|g' | grep 'r')
        chmod_bak_x=$(ls -dl $X | awk '{print $1}' | sed 's|.*\(...\)$|\1|g' | grep 'x')
        chmod o+rx $X
        [ -z "$chmod_bak_r" ] && (sleep 8;chmod o-r $X ) &
        [ -z "$chmod_bak_x" ] && (sleep 8;chmod o-x $X ) &
    done
    nohup pdnsd -c $(pwd)/bin/pdnsd.conf &
    config=config && [ "$break_copyright" = "on" ] && config=break_copyright
    nohup chpst -u 3004 v2ray -config $(pwd)/bin/${config}.json &
    sleep $v2ray_wait
    nohup redsocks2 -c $(pwd)/bin/redsocks2.conf &
    [ -z "$wp_if_system" ] || mount -o remount,ro /system
} > /dev/null 2>&1

add_iptables() {
    iptables -t nat -N VNO
    iptables -t nat -I OUTPUT -j VNO
    iptables -t nat -N VNP
    iptables -t nat -I PREROUTING -j VNP
    iptables -t mangle -N VMO
    iptables -t mangle -N VMP
    iptables -t mangle -I OUTPUT -j VMO
    iptables -t mangle -I PREROUTING -j VMP
}

app_direct() {
    for X in ${app_direct};do
        app_info=$(grep "$X " /data/system/packages.list)
        F=$(echo "$app_info" | awk '{print $2}')
        X=$(echo "$app_info" | awk '{print $1}')
        [ -z "$F" ] || iptables -t mangle -A VMO -m owner --uid-owner $F -j ACCEPT
        [ -z "$F" ] || iptables -t nat -A VNO -m owner --uid-owner $F -j ACCEPT
    done
}

udp_iptables() {
    ip route add local 0.0.0.0/0 dev lo table 121
    ip rule add fwmark 0x33772 table 121
    [ "$wifi_proxy" = "off" ] && iptables -t mangle -A VMO -o wlan+ -j ACCEPT
    iptables -t mangle -A VMO -d "$special_ip" -j ACCEPT
    iptables -t mangle -A VMP -d "$special_ip" -j ACCEPT
    iptables -t mangle -A VMO -p udp ! --dport 53 -j MARK --set-mark 0x33772
    iptables -t mangle -A VMP -p udp ! --dport 53 -j TPROXY --on-port 33774 --tproxy-mark 0x33772
    [ "$?" = "2" ] && echo && echo "  TPROXY启动失败，请关掉UDP代理" && (v2local_stop;exit 0)
}

necessary_iptables() {
    iptables -t mangle -I VMO ! -o wlan+ -p icmp -j DROP
    [ "$wifi_proxy" = "off" ] && iptables -t nat -A VNO -o wlan+ -j ACCEPT
    iptables -t nat -A VNO -p udp --dport 53 -j REDIRECT --to 33773
    [ -z "$network_whitelist" ] || iptables -t mangle -I VMO -o $network ! -s "${network_whitelist}/16" -j DROP
    iptables -t nat -A VNO -p tcp -d $address --dport $port -m owner --uid-owner 3004 -j ACCEPT
    iptables -t nat -A VNO -p tcp --dport 443 -m owner --uid-owner 3004 -j ACCEPT
    [ "$break_copyright" = "on" ] && iptables -t nat -A VNO -p tcp --dport 80 -m owner --uid-owner 3004 -j ACCEPT
    iptables -t nat -A VNO -p tcp -d "$special_ip" -j ACCEPT
    iptables -t nat -A VNO -p tcp -j REDIRECT --to 33771
}

hot_tcp_iptables() {
    iptables -t nat -A VNP -p tcp -d "$special_ip" -j ACCEPT
    iptables -t nat -A VNP -p udp --dport 53 -j REDIRECT --to 33773
    iptables -t nat -A VNP -p tcp -j REDIRECT --to 33771
}

control_network() {
    network_ip=$(ip addr show $network | grep -Eo "[0-9]*\.[0-9]*\.[0-9]*\.[0-9]*")
    judge_network_ip=$(echo $network_ip | grep "^$network_whitelist")
    var=1
    if [ ! -z "$network_ip" ];then
        echo "  当前IP：$network_ip" && echo
        while [ -z "$judge_network_ip" ];do
            settings put global airplane_mode_on 1
            am broadcast -a android.intent.action.AIRPLANE_MODE --ez state true > /dev/null 2>&1
            sleep $plane_stop
            settings put global airplane_mode_on 0
            am broadcast -a android.intent.action.AIRPLANE_MODE --ez state false > /dev/null 2>&1
            sleep $plane_wait
            network_ip=$(ip addr show $network | grep -Eo "[0-9]*\.[0-9]*\.[0-9]*\.[0-9]*")
            judge_network_ip=$(echo $network_ip | grep "^$network_whitelist")
            echo "  当前IP：$network_ip" && echo
            [ "$var" = "20" ] && v2local_check && exit 0
            var=$(($var+1))
        done
    fi
}

main() {
    #检查权限，定义变量
    pre_v2local
    if [ -z "$jzdh" ];then
        #停止v2local
        v2local_stop
        #调内网
        [ -z "$network_whitelist" ] || control_network
        #编辑配置文件
        vim_config
        #启动相关模块
        v2local_bin_start
        #创建初始规则
        add_iptables
        #放行应用
        [ -z "$app_direct" ] || app_direct
        #udp规则
        [ "$udp_proxy" = "on" ] && udp_iptables
        #热点规则
        [ "$hot_tcp_proxy" = "on" ] && hot_tcp_iptables
        #tcp主规则
        necessary_iptables
        #获取v2local运行状态
        v2local_check
    elif [ "$jzdh" = "stop" ];then
        #停止v2local
        v2local_stop
        #获取v2local运行状态
        v2local_check
    elif [ "$jzdh" = "check" ];then
        #获取v2local运行状态
        v2local_check
    fi
}

main

