#!/bin/bash
export PATH="/bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin:/usr/local/sbin"
wp="/usr/local/ssr_jzdh"

RED="\033[31m"      # Error message
GREEN="\033[32m"    # Success message
YELLOW="\033[33m"   # Warning message
BLUE="\033[36m"     # Info message

colorEcho(){
    COLOR=$1
    echo -e "${COLOR}${@:2}\033[0m"
    echo
}

cmd_need(){
    colorEcho $BLUE "正在安装 $1 ..."
    if [ -z "$(command -v yum)" ];then
        apt-get install $1 -y
    else
        yum install $1 -y
    fi > /dev/null 2>&1
    if [ "$?" != "0" ];then
        colorEcho $RED "相关命令安装失败！"
        exit 1
    fi
}

install_ssr(){
    colorEcho $BLUE "正在安装ssr..."
    cd $wp/shadowsocksr
    bash setup_cymysql.sh >/dev/null 2>&1
    bash initcfg.sh
    public_ip=$(curl -s http://members.3322.org/dyndns/getip)
    sed -i "s|SERVER_PUB_ADDR = .*|SERVER_PUB_ADDR = '$public_ip'|" $wp/shadowsocksr/userapiconfig.py
    chmod -R 777 $wp
    
    colorEcho $BLUE "正在开启ssr自启程序..."
    cat $wp/ssr.service > /etc/systemd/system/ssr.service
    cat $wp/koolproxy.service > /etc/systemd/system/koolproxy.service
    systemctl daemon-reload

    colorEcho $BLUE "正在安装ssr控制面板..."
    cat $wp/manage_pannel.sh > /bin/ssr
    chmod +x /bin/ssr

    colorEcho $BLUE "正在开启自动更新程序..."
    sed -i '/ssr_update\.sh/d' /etc/crontab
    echo "00 03 * * * root $wp/ssr_update.sh" >> /etc/crontab
}

install_libsodium() {
    colorEcho $BLUE "正在安装libsodium..."
    if command -v apt-get >/dev/null;then
        wget -q -N --no-check-certificate http://ftp.debian.org/debian/pool/main/libs/libsodium/libsodium18_1.0.13-1~bpo8+1_amd64.deb
        wget -q -N --no-check-certificate http://ftp.debian.org/debian/pool/main/libs/libsodium/libsodium-dbg_1.0.13-1~bpo8+1_amd64.deb
        dpkg -i libsodium18_1.0.13-1~bpo8+1_amd64.deb >/dev/null 2>&1
        dpkg -i libsodium-dbg_1.0.13-1~bpo8+1_amd64.deb >/dev/null 2>&1
        rm -f libsodium18_1.0.13-1~bpo8+1_amd64.deb
        rm -f libsodium-dbg_1.0.13-1~bpo8+1_amd64.deb
    else
        wget -q -N --no-check-certificate http://dl.fedoraproject.org/pub/epel/7/x86_64/Packages/l/libsodium-1.0.16-1.el7.x86_64.rpm
        yum install libsodium-1.0.16-1.el7.x86_64.rpm -y >/dev/null 2>&1
    fi
}

add_one_port(){
    read -p $'\033[33m请添加一个端口[默认随机]: \033[0m' Port
    [ -z "$Port" ] && Port=$(($RANDOM+37))
    echo
    read -p $'\033[33m请设置密码[默认随机]: \033[0m' Passport
    [ -z "$Passport" ] && Passport=$(($RANDOM * 1317))
    echo
    read -p $'\033[33m请设置流量[单位G][默认999]: \033[0m' Trafic
    [ -z "$Trafic" ] && Trafic=999
    echo

    cd $wp/shadowsocksr
    python mujson_mgr.py -a -u $Port -p $Port -k $Passport -m chacha20 -O auth_sha1_v4 -o http_simple -t $Trafic >/dev/null 2>&1
}

main(){
    cmd_need "unzip wget curl net-tools git python"
    install_ssr
    install_libsodium
    add_one_port
    systemctl enable ssr.service >/dev/null 2>&1 ; systemctl start ssr.service
    colorEcho $GREEN "ssr安装完成！输入ssr可进入控制面板！"
}

main
