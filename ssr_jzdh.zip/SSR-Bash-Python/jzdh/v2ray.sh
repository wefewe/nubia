#!/bin/bash

#安装v2ray
rm -rf /usr/local/bin/v2ray > /dev/null 2>&1
rm -f /etc/systemd/system/v2ray.service > /dev/null 2>&1
mkdir /usr/local/bin/v2ray
cp ${0%/*}/v2ray /usr/local/bin/v2ray
cp ${0%/*}/v2ctl /usr/local/bin/v2ray
cp ${0%/*}/config.json /usr/local/bin/v2ray
cp ${0%/*}/v2ray.service /etc/systemd/system
UUID=`cat /proc/sys/kernel/random/uuid`
echo -e '{\n    "inbound": {\n        "port": 80,\n        "protocol": "vmess",\n        "settings": {\n            "clients": [\n                {\n                    "id": "'$UUID'",\n                    "alterId": 100\n                }\n            ]\n        },\n        "streamSettings": {\n            "network": "tcp",\n            "tcpSettings": {\n                "header": {\n                    "type": "http",\n                    "response": {\n                        "version": "1.1",\n                        "status": "200",\n                        "reason": "OK",\n                        "headers": {\n                            "Content-Type": ["application/octet-stream", "application/x-msdownload", "text/html", "application/x-shockwave-flash"],\n                            "Connection": ["keep-alive"]\n                        }\n                    }\n                }\n            }\n        }\n    },\n    "inboundDetour": [\n        {\n            "port": 8080,\n            "protocol": "vmess",\n            "settings": {\n                "clients": [\n                    {\n                        "id": "'$UUID'",\n                        "alterId": 100\n                    }\n                ]\n            },\n            "streamSettings": {\n                "network": "tcp",\n                "tcpSettings": {\n                    "header": {\n                        "type": "http",\n                        "response": {\n                            "version": "1.1",\n                            "status": "200",\n                            "reason": "OK",\n                            "headers": {\n                                "Content-Type": ["application/octet-stream", "application/x-msdownload", "text/html", "application/x-shockwave-flash"],\n                                "Connection": ["keep-alive"]\n                            }\n                        }\n                    }\n                }\n            }\n        }\n    ],\n    "outbound": {\n        "protocol": "freedom",\n        "settings": {}\n    }\n}' > /usr/local/bin/v2ray/config.json
chmod 0777 -R /usr/local/bin/v2ray

#启动v2ray
pkill v2ray
rm -rf /etc/v2ray > /dev/null 2>&1
rm -rf /usr/bin/v2ray > /dev/null 2>&1
systemctl stop v2ray.service
systemctl enable v2ray.service
systemctl start v2ray.service

#控制面板
rm -f /bin/v2 > /dev/null 2>&1
cp ${0%/*}/v2 /bin
chmod +x /bin/v2

#提示
clear
echo
echo " v2ray的安装已完成并且正在运行，输入v2进入控制面板"
echo
