#!/bin/bash
wp=/root/SSR-Bash-Python/
yum update -y || apt-get update -y
yum install curl net-tools -y || apt-get install curl net-tools -y

function getaddip {
    python << jzdh
import socket
s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
s.connect(('119.29.29.29', 80))
print(s.getsockname()[0])
s.close()
jzdh
}
gwip=$(getaddip)


cp ${wp}jzdh/jzdh /bin;chmod +x /bin/jzdh;sed -i s/yourip/${gwip}/g ${wp}ssr;rm -f ${wp}jzdh/jzdh
clear
echo
echo ' 安装完成后输入jzdh即可获取帮助'
echo
echo ' 1.安装   ssr'
echo ' 2.安装   bbr(会重启)'
echo ' 3.安装   锐速(会重启)'
echo ' 4.安装   ssr bbr'
echo ' 5.安装   ssr 锐速'
echo
echo ' 6.安装   v2ray'
echo " 7.安装   v2ray bbr"
echo " 8.安装   v2ray 锐速"
echo
read -p '输入序号:' choice
ssr=`echo '80端口的配置:';cd ${wp};unzip shadowsocksr.zip > /dev/null 2>&1;cd shadowsocksr;python mujson_mgr.py -a -u 1 -p 80 -k 239 -m chacha20 -O auth_sha1_v4 -o http_simple -t 700 -G 10 | sed -n '$p';rm -rf ${wp}shadowsocksr`

if [ $choice -eq 1 ];then
    clear;echo ${ssr};echo;echo ' 安装完成后输入jzdh可获取本脚本的帮助,按下回车继续';echo;read
    bash ${wp}install.sh
elif [ $choice -eq 2 ];then
    bash ${wp}jzdh/bbr.sh;reboot
elif [ $choice -eq 3 ];then
    bash ${wp}jzdh/serverspeeder.sh;reboot
elif [ $choice -eq 4 ];then
    clear;echo ${ssr};echo
    bash ${wp}install.sh
    bash ${wp}jzdh/bbr.sh
    rm -f /root/uuio;reboot
elif [ $choice -eq 5 ];then
    clear;echo ${ssr};echo
    bash ${wp}install.sh
    bash ${wp}jzdh/serverspeeder.sh
    rm -f /root/uuio;reboot
elif [ $choice -eq 6 ];then
    bash ${wp}jzdh/v2ray.sh
elif [ $choice -eq 7 ];then
    bash ${wp}jzdh/v2ray.sh
    bash ${wp}jzdh/bbr.sh
elif [ $choice -eq 8 ];then
    bash ${wp}jzdh/v2ray.sh
    bash ${wp}jzdh/serverspeeder.sh
fi
