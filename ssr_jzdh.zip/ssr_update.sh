#!/bin/bash
export PATH="/bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin:/usr/local/sbin"
wp="/usr/local/ssr_jzdh"

koolproxy=off

update_koolproxy() {
    rm -rf /tmp/koolproxy && mkdir -p /tmp/koolproxy && cd /tmp/koolproxy
    wget -q -N --no-check-certificate https://kprule.com/koolproxy.txt
    koolproxy_size=$(ls -hl koolproxy.txt | awk '{print $5}' | sed 's|K||')
    if (($koolproxy_size>400));then
        cat koolproxy.txt > $wp/koolproxy.txt
        [ ! -z $(pgrep koolproxy) ] && systemctl restart koolproxy.service
    fi
}

[ "$koolproxy" = "on" ] && update_koolproxy
