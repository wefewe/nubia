#!/bin/bash

#安装v2ray
rm -rf /bin/v2ray > /dev/null 2>&1
rm -f /etc/systemd/system/v2ray.service > /dev/null 2>&1
rm -f /etc/systemd/system/koolproxy.service > /dev/null 2>&1
rm -f /bin/v2 > /dev/null 2>&1
mkdir /bin/v2ray
mkdir /bin/v2ray/data
mkdir /bin/v2ray/data/rules
cp ${0%/*}/v2ray /bin/v2ray
cp ${0%/*}/v2ctl /bin/v2ray
cp ${0%/*}/koolproxy_i386 /bin/v2ray
cp ${0%/*}/kp.dat /bin/v2ray/data/rules
cp ${0%/*}/koolproxy.txt /bin/v2ray/data/rules
cp ${0%/*}/v2ray.service /etc/systemd/system
cp ${0%/*}/koolproxy.service /etc/systemd/system
UUID=`cat /proc/sys/kernel/random/uuid`
echo -e '{\n    "inbound": {\n        "port": 80,\n        "protocol": "vmess",\n        "settings": {\n            "clients": [\n                {\n                    "id": "'$UUID'",\n                    "alterId": 100\n                }\n            ]\n        },\n        "streamSettings": {\n            "network": "tcp",\n            "tcpSettings": {\n                "header": {\n                    "type": "http",\n                    "response": {\n                        "version": "1.1",\n                        "status": "200",\n                        "reason": "OK",\n                        "headers": {\n                            "Content-Type": ["application/octet-stream", "application/x-msdownload", "text/html", "application/x-shockwave-flash"],\n                            "Connection": ["keep-alive"]\n                        }\n                    }\n                }\n            }\n        }\n    },\n    "inboundDetour": [\n        {\n            "port": 8080,\n            "protocol": "vmess",\n            "settings": {\n                "clients": [\n                    {\n                        "id": "'$UUID'",\n                        "alterId": 100\n                    }\n                ]\n            },\n            "streamSettings": {\n                "network": "tcp",\n                "tcpSettings": {\n                    "header": {\n                        "type": "http",\n                        "response": {\n                            "version": "1.1",\n                            "status": "200",\n                            "reason": "OK",\n                            "headers": {\n                                "Content-Type": ["application/octet-stream", "application/x-msdownload", "text/html", "application/x-shockwave-flash"],\n                                "Connection": ["keep-alive"]\n                            }\n                        }\n                    }\n                }\n            }\n        }\n    ],\n    "outbound": {\n        "protocol": "freedom",\n        "settings": {}\n    }\n}' > /bin/v2ray/config.json
chmod 0777 -R /bin/v2ray
userdel koolproxy_i386 > /dev/null 2>&1
useradd koolproxy_i386

#启动v2ray
systemctl stop v2ray.service
systemctl enable v2ray.service
systemctl start v2ray.service

#控制面板
cp ${0%/*}/v2 /bin
chmod +x /bin/v2
