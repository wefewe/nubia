#!/bin/bash
export PATH="/bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin:/usr/local/sbin"
wp="/usr/local/v2ray"

RED="31m"      # Error message
GREEN="32m"    # Success message
YELLOW="33m"   # Warning message
BLUE="36m"     # Info message

colorEcho(){
    COLOR=$1
    echo -e "\033[${COLOR}${@:2}\033[0m"
    echo
}

cmd_need(){
    colorEcho $BLUE "正在安装 $1 ..."
    $Installer install $1 -y > /dev/null 2>&1
    if [ "$?" != "0" ];then
        colorEcho $RED "命令安装失败！"
        exit 1
    fi
}

check_system(){
    Installer=$(command -v apt-get 2>/dev/null) || Installer=$(command -v yum 2>/dev/null) || colorEcho $RED "系统不支持，找不到apt-get或者yum！"
    SYSTEMCTL=$(command -v systemctl 2>/dev/null) || colorEcho $RED "系统不支持，找不到systemctl！"
    if [ "$(uname -m)" = "x86_64" ];then
        VDIS=64
    elif [ "$(uname -m)" = "i686" ] || [ "$(uname -m)" = "i386" ];then
        VDIS=32
    else
        colorEcho $RED "脚本仅支持X86架构设备！"
    fi
    if [ -z "$Installer" ] || [ -z "$SYSTEMCTL" ] || [ -z "$VDIS" ];then
        exit 1
    fi
}

install_v2ray(){
    colorEcho $BLUE "正在安装V2Ray核心..."
    rm -rf /tmp/v2ray && mkdir -p /tmp/v2ray && cd /tmp/v2ray
    v2ray_latest_version=$(curl -s https://github.com/v2ray/v2ray-core/releases/latest | sed 's|.*tag/\(.*\)".*|\1|')
    wget -q -N --no-check-certificate https://github.com/v2ray/v2ray-core/releases/download/${v2ray_latest_version}/v2ray-linux-${VDIS}.zip
    unzip -q -o v2ray-linux-${VDIS}.zip "*/v2ray" "*/v2ctl"
    cp */v2ray $wp ; cp */v2ctl $wp
    chmod -R 777 $wp

    colorEcho $BLUE "正在开启V2Ray自启程序..."
    cat $wp/v2ray.service > /etc/systemd/system/v2ray.service
    cat $wp/koolproxy.service > /etc/systemd/system/koolproxy.service
    systemctl daemon-reload

    colorEcho $BLUE "正在安装V2Ray控制面板..."
    cat $wp/manage_pannel.sh > /bin/v2
    chmod +x /bin/v2
    
    colorEcho $BLUE "正在开启自动更新程序..."
    sed -i '/v2ray_update\.sh/d' /etc/crontab
    echo "00 03 * * * $wp/v2ray_update.sh" >> /etc/crontab
}

config_reload() {
    echo -e '{\n  "inbound": {\n    "port": '$(sed -n "1p" $wp/v2ray.ini | awk '{print $1}')',\n    "protocol": "vmess",\n    "settings": {\n      "clients": [\n        {\n          "id": "'$(sed -n "1p" $wp/v2ray.ini | awk '{print $2}')'",\n          "alterId": 100\n        }\n      ]\n    },\n    "streamSettings": {\n      "network": "tcp",\n      "tcpSettings": {\n        "header": {\n          "type": "http",\n          "response": {\n            "version": "1.1",\n            "status": "200",\n            "reason": "OK",\n            "headers": {\n              "Content-Type": [\n                "application/octet-stream",\n                "application/x-msdownload",\n                "text/html",\n                "application/x-shockwave-flash"\n              ],\n              "Connection": [\n                "keep-alive"\n              ]\n            }\n          }\n        }\n      }\n    }\n  },\n  "outbound": {\n    "protocol": "freedom",\n    "settings": {}\n  }\n}' > $wp/config.json
}

add_one_port(){
    read -p $'\033[33m请添加一个端口[默认随机]: \033[0m' Port
    [ -z "$Port" ] && Port=$(($RANDOM+37))
    echo
    read -p $'\033[33m请设置UUID[默认随机]: \033[0m' UUID
    [ -z "$UUID" ] && UUID=$(cat /proc/sys/kernel/random/uuid)
    echo
    echo "$Port $UUID" > $wp/v2ray.ini
    config_reload
}

main(){
    check_system
    cmd_need "unzip wget curl net-tools"
    install_v2ray
    add_one_port
    $SYSTEMCTL enable v2ray.service >/dev/null 2>&1; $SYSTEMCTL start v2ray.service
    colorEcho $GREEN "V2Ray安装完成！输入v2可进入控制面板！"
}

main
