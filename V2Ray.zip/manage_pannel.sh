#!/bin/bash
export PATH="/bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin:/usr/local/sbin"
wp="/usr/local/bin/v2ray"

config_reload() {
    v2ray_config_line=$(cat $wp/v2ray.ini | wc -l)
    if [ "$v2ray_config_line" = "1" ];then
        echo -e '{\n  "inbound": {\n    "port": '$(sed -n "1p" $wp/v2ray.ini | awk '{print $1}')',\n    "protocol": "vmess",\n    "settings": {\n      "clients": [\n        {\n          "id": "'$(sed -n "1p" $wp/v2ray.ini | awk '{print $2}')'",\n          "alterId": 100\n        }\n      ]\n    },\n    "streamSettings": {\n      "network": "tcp",\n      "tcpSettings": {\n        "header": {\n          "type": "http",\n          "response": {\n            "version": "1.1",\n            "status": "200",\n            "reason": "OK",\n            "headers": {\n              "Content-Type": [\n                "application/octet-stream",\n                "application/x-msdownload",\n                "text/html",\n                "application/x-shockwave-flash"\n              ],\n              "Connection": [\n                "keep-alive"\n              ]\n            }\n          }\n        }\n      }\n    }\n  },\n  "outbound": {\n    "protocol": "freedom",\n    "settings": {}\n  }\n}' > $wp/config.json
    elif (("$v2ray_config_line" > "1"));then
        echo -e '{\n  "inbound": {\n    "port": '$(sed -n "1p" $wp/v2ray.ini |awk '{print $1}')',\n    "protocol": "vmess",\n    "settings": {\n      "clients": [\n        {\n          "id": "'$(sed -n "1p" $wp/v2ray.ini | awk '{print $2}')'",\n          "alterId": 100\n        }\n      ]\n    },\n    "streamSettings": {\n      "network": "tcp",\n      "tcpSettings": {\n        "header": {\n          "type": "http",\n          "response": {\n            "version": "1.1",\n            "status": "200",\n            "reason": "OK",\n            "headers": {\n              "Content-Type": [\n                "application/octet-stream",\n                "application/x-msdownload",\n                "text/html",\n                "application/x-shockwave-flash"\n              ],\n              "Connection": [\n                "keep-alive"\n              ]\n            }\n          }\n        }\n      }\n    }\n  },\n  "inboundDetour": [' > $wp/config.json
        v2ray_ports=$(grep -Eo "^[0-9]{1,5} " $wp/v2ray.ini)
        for N in ${v2ray_ports};do
            v2ray_uuid=$(grep "$N " $wp/v2ray.ini | awk '{print $2}')
            echo -e '    {\n      "port": '$N',\n      "protocol": "vmess",\n      "settings": {\n        "clients": [\n          {\n            "id": "'$v2ray_uuid'",\n            "alterId": 100\n          }\n        ]\n      },\n      "streamSettings": {\n        "network": "tcp",\n        "tcpSettings": {\n          "header": {\n            "type": "http",\n            "response": {\n              "version": "1.1",\n              "status": "200",\n              "reason": "OK",\n              "headers": {\n                "Content-Type": [\n                  "application/octet-stream",\n                  "application/x-msdownload",\n                  "text/html",\n                  "application/x-shockwave-flash"\n                ],\n                "Connection": [\n                  "keep-alive"\n                ]\n              }\n            }\n          }\n        }\n      }\n    },' >> $wp/config.json
        done
        echo -e '  ],\n  "outbound": {\n    "protocol": "freedom",\n    "settings": {}\n  }\n}' >> $wp/config.json
        sed -i ':a;N;$!ba;s|,\n  \]|\n  \]|' $wp/config.json
    fi
}

ports_setting(){
    echo
    echo "  1. 添加一个端口"
    echo "  2. 删除一个端口"
    echo "  3. 更改端口UUID"
    echo
    read -p "请选择: " ports_setting_choice
    echo

    case $ports_setting_choice in
        1)
            read -p "请输入端口[默认随机]: " Port
            [ -z "$Port" ] && Port=$(($RANDOM+37))
            echo
            read -p "请设置UUID[默认随机]: " UUID
            [ -z "$UUID" ] && UUID=$(cat /proc/sys/kernel/random/uuid)
            echo "$Port $UUID" >> $wp/v2ray.ini
            config_reload
            systemctl stop v2ray.service
            systemctl start v2ray.service
            ;;
        2)
            if (($(cat $wp/v2ray.ini | wc -l)>1));then
                var=1
                for Echo in $v2ray_ports;do
                    echo " $var. 删除$Echo端口"
                    var=$(($var+1))
                done
                echo
                read -p "请选择: " input_choice
                if [ ! -z "$input_choice" ];then
                    sed -i "${input_choice}d" $wp/v2ray.ini
                    config_reload
                    systemctl stop v2ray.service
                    systemctl start v2ray.service
                fi
            fi
            ;;
        3)
            var=1
            for Echo in $v2ray_ports;do
                echo " $var. 更改$Echo端口UUID"
                var=$(($var+1))
            done
            echo
            read -p "请选择: " input_choice
            if [ ! -z "$input_choice" ];then
                echo
                read -p "请设置UUID[默认随机]: " UUID
                [ -z "$UUID" ] && UUID=$(cat /proc/sys/kernel/random/uuid)
                sed -i "${input_choice}s| .*| $UUID|" $wp/v2ray.ini
                config_reload
                systemctl stop v2ray.service
                systemctl start v2ray.service
            fi
            ;;
        *)
            #bad command
            ;;
    esac
}

update_core(){
    [ "$(uname -m)" = "x86_64" ] && VDIS=64 || VDIS=32
    rm -rf /tmp/v2ray && mkdir -p /tmp/v2ray && cd /tmp/v2ray
    wget -q -N --no-check-certificate https://github.com/v2ray/v2ray-core/releases/download/${latest_core}/v2ray-linux-${VDIS}.zip
    unzip -q -o v2ray-linux-${VDIS}.zip "*/v2ray" "*/v2ctl"
    $(command -v cp) -f */v2ray $wp ; $(command -v cp) */v2ctl $wp
    chmod -R 777 $wp
    systemctl stop v2ray.service
    systemctl start v2ray.service
}

show_config() {
    if grep "^##" /bin/v2;then
        public_ip=$(grep "^##" /bin/v2 | grep -Eo '([0-9]{1,3}\.){3}[0-9]{1,3}')
    else
        public_ip=$(curl -s ifconfig.me)
        echo $public_ip | sed 's|^|##|' >> /bin/v2
        fi
                v2ray_ports=$(grep -Eo "^[0-9]{1,5}" $wp/v2ray.ini)
                echo
                echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
                for K in ${v2ray_ports};do
                    v2ray_uuid=$(grep "$K " $wp/v2ray.ini | awk '{print $2}')
                    v2rayNG=$(echo '{"add":"'$public_ip'","aid":"100","host":"k.youku.com","id":"'$v2ray_uuid'","net":"tcp","path":"","port":"'$K'","ps":"'$public_ip'","tls":"","type":"http","v":"2"}' | base64 | sed ':a;N;$!ba;s|\n||g' | sed 's|^|vmess://|')
                    echo -e "v2rayNG: \033[33m${v2rayNG}\033[0m"
                    echo
                    echo -e "服务IP:   \033[33m${public_ip}\033[0m"
                    echo -e "服务端口: \033[33m${K}\033[0m"
                    echo -e "用户ID:   \033[33m${v2ray_uuid}\033[0m"
                    echo -e "额外ID:   \033[33m100\033[0m"
                    echo -e "加密方式: \033[33m任意选择\033[0m"
                    echo -e "传输协议: \033[33mtcp\033[0m"
                    echo -e "伪装类型: \033[33mhttp\033[0m"
                    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
                done
                exit 0
            }

        show_connections() {
            awk_ports=$(awk '{print $1}' $wp/v2ray.ini | sed 's|^|\:|g;s|$|\$|g' | tr "\n" "|" | sed 's|\|$||')
            connection_ip=$(netstat -anp | grep "^tcp.*ESTABLISHED" | awk '{if($4~/('$awk_ports')/)print $5}' | grep -Eo "[0-9]*\.[0-9]*\.[0-9]*\.[0-9]*" | sort -u)
            clear
            v2ray_ports=$(grep -Eo "^[0-9]{1,5}" $wp/v2ray.ini)
            for L in ${v2ray_ports};do
                echo "${L}端口："
                connection_ip=$(netstat -anp | grep "^tcp.*ESTABLISHED" | awk '{if($4~/:'$L'$/)print $5}' | grep -Eo "[0-9]*\.[0-9]*\.[0-9]*\.[0-9]*" | sort -u)
                for X in ${connection_ip};do
                    echo -e "  \033[33m${X}\033[0m"
                done
                echo
            done
        }

    pannel(){
        pgrep v2ray >/dev/null 2>&1 && v2ray_status="\033[32mV2Ray\033[0m" || v2ray_status="\033[31mV2Ray\033[0m"
        pgrep koolproxy >/dev/null 2>&1 && koolproxy_status="\033[32mKoolProxy\033[0m" || koolproxy_status="\033[31mKoolProxy\033[0m"
        old_core=$($wp/v2ray -version | sed -n "1p" | awk '{print $2}')
        latest_core=$(curl -s https://github.com/v2ray/v2ray-core/releases/latest | sed 's|.*tag/\(.*\)".*|\1|')
        v2ray_ports=$(awk '{print $1}' $wp/v2ray.ini | tr "\n" " ")
        awk_ports=$(awk '{print $1}' $wp/v2ray.ini | sed 's|^|\:|g;s|$|\$|g' | tr "\n" "|" | sed 's|\|$||')
        connections=$(netstat -anp | grep "^tcp.*ESTABLISHED" | awk '{if($4~/('$awk_ports')/)print $5}' | grep -Eo '([0-9]{1,3}\.){3}[0-9]{1,3}' | sort -u | wc -l)

        clear
        echo "V2Ray多功能脚本，欢迎使用！"
        echo
        echo -e "  1. 启动$v2ray_status"
        echo "  2. 关闭V2Ray"
        echo "  3. 重启V2Ray"
        echo -e "  4. 升级V2Ray核心 \033[33m$old_core\033[0m \033[32m$latest_core\033[0m"
        echo "  5. 卸载V2Ray"
        echo "━━━━━━━━━━━━━━━━━━━━━━━━"
        echo -e "  6. 端口设置 \033[33m$v2ray_ports\033[0m"
        echo "  7. 查看客户端配置"
        echo -e "  8. 查看设备连接数量 \033[33m$connections\033[0m"
        echo "━━━━━━━━━━━━━━━━━━━━━━━━"
        echo -e "  9. 启动$koolproxy_status去广告"
        echo " 10. 关闭KoolProxy去广告"
        echo " 11. 重启KoolProxy去广告"
        echo
        read -p "请选择：" pannel_choice

        case $pannel_choice in
            1)
                systemctl start v2ray.service
                systemctl enable v2ray.service >/dev/null 2>&1
                pannel
                ;;
            2)
                systemctl stop v2ray.service
                systemctl disable v2ray.service >/dev/null 2>&1
                pannel
                ;;
            3)
                systemctl stop v2ray.service
                systemctl start v2ray.service
                systemctl enable v2ray.service >/dev/null 2>&1
                pannel
                ;;
            4)
                update_core
                pannel
                ;;
            5)
                bash $wp/uninstall.sh
                clear && echo "V2Ray已卸载！"
                ;;
            6)
                ports_setting
                pannel
                ;;
            7)
                show_config
                ;;
            8)
                show_connections
                pannel
                ;;
            9)
                iptables -t nat -D OUTPUT -m owner --uid-owner koolproxy -j ACCEPT 2>/dev/null
                iptables -t nat -D OUTPUT -p tcp --dport 80 -j REDIRECT --to 3000 2>/dev/null
                useradd koolproxy 2>/dev/null
                iptables -t nat -A OUTPUT -m owner --uid-owner koolproxy -j ACCEPT
                iptables -t nat -A OUTPUT -p tcp --dport 80 -j REDIRECT --to 3000
                systemctl start koolproxy.service
                systemctl enable koolproxy.service >/dev/null 2>&1
                ;;
            10)
                iptables -t nat -D OUTPUT -m owner --uid-owner koolproxy -j ACCEPT 2>/dev/null
                iptables -t nat -D OUTPUT -p tcp --dport 80 -j REDIRECT --to 3000 2>/dev/null
                systemctl stop koolproxy.service
                systemctl disable koolproxy.service >/dev/null 2>&1
                pannel
                ;;
            11)
                iptables -t nat -D OUTPUT -m owner --uid-owner koolproxy -j ACCEPT 2>/dev/null
                iptables -t nat -D OUTPUT -p tcp --dport 80 -j REDIRECT --to 3000 2>/dev/null
                useradd koolproxy 2>/dev/null
                iptables -t nat -A OUTPUT -m owner --uid-owner koolproxy -j ACCEPT
                iptables -t nat -A OUTPUT -p tcp --dport 80 -j REDIRECT --to 3000
                systemctl stop koolproxy.service
                systemctl start koolproxy.service
                systemctl enable koolproxy.service >/dev/null 2>&1
                ;;
            *)
                exit 0
                ;;
        esac
    }

pannel
