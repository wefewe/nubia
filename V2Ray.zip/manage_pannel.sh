#!/bin/bash
export PATH="/bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin:/usr/local/sbin"
wp="/usr/local/v2ray"

config_reload() {
    v2ray_config_line=$(cat $wp/v2ray.ini | wc -l)
    if [ "$v2ray_config_line" = "1" ];then
        echo -e '{\n  "inbound": {\n    "port": '$(sed -n "1p" $wp/v2ray.ini | awk '{print $1}')',\n    "protocol": "vmess",\n    "settings": {\n      "clients": [\n        {\n          "id": "'$(sed -n "1p" $wp/v2ray.ini | awk '{print $2}')'",\n          "alterId": 100\n        }\n      ]\n    },\n    "streamSettings": {\n      "network": "tcp",\n      "tcpSettings": {\n        "header": {\n          "type": "http",\n          "response": {\n            "version": "1.1",\n            "status": "200",\n            "reason": "OK",\n            "headers": {\n              "Content-Type": [\n                "application/octet-stream",\n                "application/x-msdownload",\n                "text/html",\n                "application/x-shockwave-flash"\n              ],\n              "Connection": [\n                "keep-alive"\n              ]\n            }\n          }\n        }\n      }\n    }\n  },\n  "outbound": {\n    "protocol": "freedom",\n    "settings": {}\n  }\n}' > $wp/config.json
    elif (("$v2ray_config_line" > "1"));then
        echo -e '{\n  "inbound": {\n    "port": '$(sed -n "1p" $wp/v2ray.ini |awk '{print $1}')',\n    "protocol": "vmess",\n    "settings": {\n      "clients": [\n        {\n          "id": "'$(sed -n "1p" $wp/v2ray.ini | awk '{print $2}')'",\n          "alterId": 100\n        }\n      ]\n    },\n    "streamSettings": {\n      "network": "tcp",\n      "tcpSettings": {\n        "header": {\n          "type": "http",\n          "response": {\n            "version": "1.1",\n            "status": "200",\n            "reason": "OK",\n            "headers": {\n              "Content-Type": [\n                "application/octet-stream",\n                "application/x-msdownload",\n                "text/html",\n                "application/x-shockwave-flash"\n              ],\n              "Connection": [\n                "keep-alive"\n              ]\n            }\n          }\n        }\n      }\n    }\n  },\n  "inboundDetour": [' > $wp/config.json
        v2ray_ports=$(grep -Eo "^[0-9]{1,5}" $wp/v2ray.ini | sed "1d")
        for N in ${v2ray_ports};do
            v2ray_uuid=$(grep "$N " $wp/v2ray.ini | awk '{print $2}')
            echo -e '    {\n      "port": '$N',\n      "protocol": "vmess",\n      "settings": {\n        "clients": [\n          {\n            "id": "'$v2ray_uuid'",\n            "alterId": 100\n          }\n        ]\n      },\n      "streamSettings": {\n        "network": "tcp",\n        "tcpSettings": {\n          "header": {\n            "type": "http",\n            "response": {\n              "version": "1.1",\n              "status": "200",\n              "reason": "OK",\n              "headers": {\n                "Content-Type": [\n                  "application/octet-stream",\n                  "application/x-msdownload",\n                  "text/html",\n                  "application/x-shockwave-flash"\n                ],\n                "Connection": [\n                  "keep-alive"\n                ]\n              }\n            }\n          }\n        }\n      }\n    },' >> $wp/config.json
        done
        echo -e '  ],\n  "outbound": {\n    "protocol": "freedom",\n    "settings": {}\n  }\n}' >> $wp/config.json
        sed -i ':a;N;$!ba;s|,\n  \]|\n  \]|' $wp/config.json
    fi
}

add_port() {
    echo
    read -p $'\033[33m请输入端口[默认随机]: \033[0m' Port
    [ -z "$Port" ] && Port=$(($RANDOM+37))
    echo
    read -p $'\033[33m请设置UUID[默认随机]: \033[0m' UUID
    [ -z "$UUID" ] && UUID=$(cat /proc/sys/kernel/random/uuid)
    echo "$Port $UUID" >> $wp/v2ray.ini
    config_reload
    pgrep v2ray >/dev/null 2>&1 && systemctl restart v2ray.service
}

del_port() {
    echo
    if (($(cat $wp/v2ray.ini | wc -l)>1));then
        var=1
        for Echo in $v2ray_ports;do
            echo -e " $var. 删除\033[33m$Echo\033[0m端口"
            var=$(($var+1))
        done
        echo
        read -p $'\033[33m请选择: \033[0m' input_choice
        if [ ! -z "$input_choice" ];then
            sed -i "${input_choice}d" $wp/v2ray.ini
            config_reload
            pgrep v2ray >/dev/null 2>&1 && systemctl restart v2ray.service
        fi
    fi
}

change_uuid() {
    echo
    var=1
    for Echo in $v2ray_ports;do
        echo -e " $var. 更改\033[33m$Echo\033[0m端口UUID"
        var=$(($var+1))
    done
    echo
    read -p $'\033[33m请选择: \033[0m' input_choice
    if [ ! -z "$input_choice" ];then
        echo
        read -p $'\033[33m请设置UUID[默认随机]: \033[0m' UUID
        [ -z "$UUID" ] && UUID=$(cat /proc/sys/kernel/random/uuid)
        sed -i "${input_choice}s| .*| $UUID|" $wp/v2ray.ini
        config_reload
        pgrep v2ray >/dev/null 2>&1 && systemctl restart v2ray.service
    fi
}

show_config() {
    echo -e "\033[32m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m"
    for K in ${v2ray_ports};do
        v2ray_uuid=$(grep "^$K " $wp/v2ray.ini | awk '{print $2}')
        v2rayNG=$(echo '{"add":"'$public_ip'","aid":"100","host":"k.youku.com","id":"'$v2ray_uuid'","net":"tcp","path":"","port":"'$K'","ps":"'$public_ip'","tls":"","type":"http","v":"2"}' | base64 | sed ':a;N;$!ba;s|\n||g' | sed 's|^|vmess://|')
        printf "\033[36m%11s \033[33m%-20s\033[0m\n" "服务IP:" "${public_ip}"
        printf "\033[36m%13s \033[33m%-20s\033[0m\n" "服务端口:" "${K}"
        printf "\033[36m%11s \033[33m%-20s\033[0m\n" "用户ID:" "${v2ray_uuid}"
        printf "\033[36m%11s \033[33m%-20s\033[0m\n" "额外ID:" "100"
        printf "\033[36m%13s \033[33m%-20s\033[0m\n" "加密方式:" "任意选择"
        printf "\033[36m%13s \033[33m%-20s\033[0m\n" "传输协议:" "tcp"
        printf "\033[36m%13s \033[33m%-20s\033[0m\n" "伪装类型:" "http"
        echo        
        printf "\033[36m%9s \033[33m%-20s\033[0m\n" "v2rayNG:" "${v2rayNG}"        
        echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    done
}

pannel(){
    pgrep v2ray >/dev/null 2>&1 && v2ray_status="关闭V2Ray" || v2ray_status="开启V2Ray"
    pgrep koolproxy >/dev/null 2>&1 && koolproxy_status="关闭KoolProxy" || koolproxy_status="开启KoolProxy"
    core_version=$($wp/v2ray -version | sed -n "1p" | awk '{print $2}')
    v2ray_ports=$(awk '{print $1}' $wp/v2ray.ini)
    connections=""
    for Port in $v2ray_ports;do
        connection=$(echo -e "[\033[33m$Port\033[0m \033[32m$(netstat -anp | grep "^tcp.*ESTABLISHED" | awk '{if($4~/:'$Port'$/)print $5}' | grep -Eo '([0-9]{1,3}\.){3}[0-9]{1,3}' | sort -u | wc -l)\033[0m]")
        connections="$connection $connections"
    done
    var=1

    show_config
    echo
    echo -e "[\033[33m端口\033[0m \033[32m连接数\033[0m] $connections"
    echo
    echo -e "  $var. $v2ray_status \033[32m$core_version\033[0m" && var=$(($var+1))
    echo "  $var. $koolproxy_status去广告" && var=$(($var+1))
    echo "  $var. 卸载V2Ray" && var=$(($var+1))
    echo "  $var. 添加一个端口" && var=$(($var+1))
    echo "  $var. 删除一个端口" && var=$(($var+1))
    echo "  $var. 更改端口UUID" && var=$(($var+1))
    echo
    read -p $'\033[33m请选择：\033[0m' pannel_choice

    case $pannel_choice in
        1)
            if pgrep v2ray >/dev/null 2>&1;then
                systemctl stop v2ray.service
                systemctl disable v2ray.service >/dev/null 2>&1
                sed -i 's|v2ray=.*|v2ray=off|' $wp/v2ray_update.sh
            else
                systemctl start v2ray.service
                systemctl enable v2ray.service >/dev/null 2>&1
                sed -i 's|v2ray=.*|v2ray=on|' $wp/v2ray_update.sh
            fi
            clear && pannel
            ;;
        2)
            if pgrep koolproxy >/dev/null 2>&1;then
                iptables -t nat -D OUTPUT -p tcp -m ttl --ttl-eq 160 -j ACCEPT
                iptables -t nat -D OUTPUT -p tcp --dport 80 -j REDIRECT --to 3000
                systemctl stop koolproxy.service
                systemctl disable koolproxy.service >/dev/null 2>&1
                sed -i 's|koolproxy=.*|koolproxy=off|' $wp/v2ray_update.sh
            else
                iptables -t nat -A OUTPUT -p tcp -m ttl --ttl-eq 160 -j ACCEPT
                iptables -t nat -A OUTPUT -p tcp --dport 80 -j REDIRECT --to 3000
                systemctl start koolproxy.service
                systemctl enable koolproxy.service >/dev/null 2>&1
                sed -i 's|koolproxy=.*|koolproxy=on|' $wp/v2ray_update.sh
            fi
            clear && pannel
            ;;
        3)
            read
            bash $wp/uninstall.sh
            clear && echo "V2Ray已卸载！"
            ;;
        4)
            add_port
            clear && pannel
            ;;
        5)
            del_port
            clear && pannel
            ;;
        6)
            change_uuid
            clear && pannel
            ;;
        *)
            clear && exit 0
            ;;
    esac
}

if grep -q "^##" /bin/v2;then
    public_ip=$(grep "^##" /bin/v2 | grep -Eo '([0-9]{1,3}\.){3}[0-9]{1,3}')
else
    public_ip=$(curl -s http://members.3322.org/dyndns/getip)
    sed -i '$a##'$public_ip'' /bin/v2
fi

clear && pannel
