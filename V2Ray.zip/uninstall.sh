#!/bin/bash
export PATH="/bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin:/usr/local/sbin"
wp="/usr/local/bin/v2ray"

systemctl disable v2ray.service
systemctl stop v2ray.service
systemctl disable koolproxy.service
systemctl stop koolproxy.service

rm -rf $wp
rm -f /etc/systemd/system/v2ray.service
rm -f /etc/systemd/system/koolproxy.service
rm -f /bin/v2
