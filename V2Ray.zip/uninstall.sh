#!/bin/bash
export PATH="/bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin:/usr/local/sbin"
wp="/usr/local/v2ray"

systemctl disable v2ray.service
systemctl kill v2ray.service
systemctl disable koolproxy.service
systemctl kill koolproxy.service

iptables -t nat -D OUTPUT -m owner --uid-owner koolproxy -j ACCEPT 2>/dev/null
iptables -t nat -D OUTPUT -p tcp --dport 80 -j REDIRECT --to 3000 2>/dev/null

rm -rf $wp
rm -f /etc/systemd/system/v2ray.service
rm -f /etc/systemd/system/koolproxy.service
rm -f /bin/v2

sed -i '/v2ray_update\.sh/d' /etc/crontab