#!/bin/bash
export PATH="/bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin:/usr/local/sbin"
wp="/usr/local/AriaNG"

RED="\033[31m"      # Error message
GREEN="\033[32m"    # Success message
YELLOW="\033[33m"   # Warning message
BLUE="\033[36m"     # Info message

pannel() {
    var=1
    ariang_port=$(sed -n "1p" $wp/caddy.conf | awk -F ":" '{print $2}' | grep -Eo "[0-9]*")
    download_port=$(sed -n "7p" $wp/caddy.conf | awk -F ":" '{print $2}' | grep -Eo "[0-9]*")
    pgrep caddy >/dev/null 2>&1 && pgrep aria2c >/dev/null 2>&1 && ariang_status="$GREEN" || ariang_status=""
    system_storage=$(df -h | grep "/$" | awk '{print $4}')
    
    echo
    echo -e "    \033[36m剩余存储: \033[33m${system_storage}\033[0m"
    echo -e "  \033[36mAriaNG地址: \033[33mhttp://$public_ip:$ariang_port\033[0m"
    echo -e "\033[36m下载页面地址: \033[33mhttp://$public_ip:$download_port\033[0m"
    echo
    echo -e "  $var. 开/关${ariang_status}AriaNG\033[0m" && var=$(($var+1))
    echo "  $var. 更改AriaNG端口" && var=$(($var+1))
    echo "  $var. 更改下载页面端口" && var=$(($var+1))
    echo "  $var. 卸载AriaNG" && var=$(($var+1))
    echo "  $var. 清空已下载文件" && var=$(($var+1))
    echo
    read -p $'\033[33m请选择：\033[0m' pannel_choice

    case $pannel_choice in
        1)
            if pgrep caddy >/dev/null 2>&1 && pgrep aria2c >/dev/null 2>&1 ;then
                systemctl disable ariang_caddy.service
                systemctl stop ariang_caddy.service
                systemctl disable ariang_aria2c.service
                systemctl stop ariang_aria2c.service
                sed -i 's|aria2=.*|aria2=off|' $wp/AriaNG_update.sh
            else
                systemctl enable ariang_caddy.service
                systemctl start ariang_caddy.service
                systemctl enable ariang_aria2c.service
                systemctl start ariang_aria2c.service
                sed -i 's|aria2=.*|aria2=on|' $wp/AriaNG_update.sh
            fi >/dev/null 2>&1
            clear && pannel
            ;;
        2)
            echo
            read -p $'\033[33m请输入AriaNG端口[默认随机]: \033[0m' Port
            [ -z "$Port" ] && Port=$(($RANDOM+37))
            echo
            sed -i '1s|0.0.0.0:.* |0.0.0.0:'$Port' |' $wp/caddy.conf
            pgrep caddy >/dev/null 2>&1 && systemctl restart ariang_caddy.service
            clear && pannel
            ;;
        3)
            echo
            read -p $'\033[33m请输入下载页面端口[默认随机]: \033[0m' dPort
            [ -z "$dPort" ] && dPort=$(($RANDOM+37))
            echo
            sed -i '7s|0.0.0.0:.* |0.0.0.0:'$dPort' |' $wp/caddy.conf
            pgrep caddy >/dev/null 2>&1 && systemctl restart ariang_caddy.service
            clear && pannel
            ;;
        4)
            read
            bash $wp/uninstall.sh
            clear && echo "AriaNG已卸载！" && exit 0
            ;;
        5)
            read
            rm -rf $wp/Download/*
            clear && pannel
            ;;
    esac
}

if grep -q "^##" /bin/ag;then
    public_ip=$(grep "^##" /bin/ag | grep -Eo '([0-9]{1,3}\.){3}[0-9]{1,3}')
else
    public_ip=$(curl -s http://ip-api.com/json | grep -Eo '([0-9]{1,3}\.){3}[0-9]{1,3}')
    sed -i '$a##'$public_ip'' /bin/ag
fi

clear ; pannel
clear
