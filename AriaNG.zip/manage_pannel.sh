#!/bin/bash
export PATH="/bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin:/usr/local/sbin"
wp="/usr/local/AriaNG"

pannel() {
    var=1
    ariang_port=$(grep 'listen' $wp/nginx.conf | grep -Eo "[0-9]*" | sed -n "1p")
    download_port=$(grep 'listen' $wp/nginx.conf | grep -Eo "[0-9]*" | sed -n "2p")
    pgrep nginx >/dev/null 2>&1 && pgrep aria2c >/dev/null 2>&1 && ariang_status="关闭" || ariang_status="启动"
    system_storage=$(df -h | grep "/$" | awk '{print $4}')
    
    echo
    echo -e "    \033[36m剩余存储: \033[33m${system_storage}\033[0m"
    echo -e "  \033[36mAriaNG地址: \033[33mhttp://$public_ip:$ariang_port\033[0m"
    echo -e "\033[36m下载页面地址: \033[33mhttp://$public_ip:$download_port\033[0m"
    echo
    echo "  $var. ${ariang_status}AriaNG" && var=$(($var+1))
    echo "  $var. 更改AriaNG端口" && var=$(($var+1))
    echo "  $var. 更改下载页面端口" && var=$(($var+1))
    echo "  $var. 卸载AriaNG" && var=$(($var+1))
    echo "  $var. 清空已下载文件" && var=$(($var+1))
    echo
    read -p $'\033[33m请选择：\033[0m' pannel_choice

    case $pannel_choice in
        1)
            if pgrep nginx >/dev/null 2>&1 && pgrep aria2c >/dev/null 2>&1 ;then
                systemctl disable ariang_nginx.service >/dev/null 2>&1
                systemctl stop ariang_nginx.service
                systemctl disable ariang_aria2c.service >/dev/null 2>&1
                systemctl stop ariang_aria2c.service
                sed -i 's|aria2=.*|aria2=off|' $wp/AriaNG_update.sh
            else
                systemctl enable ariang_nginx.service >/dev/null 2>&1
                systemctl start ariang_nginx.service
                systemctl enable ariang_aria2c.service >/dev/null 2>&1
                systemctl start ariang_aria2c.service
                sed -i 's|aria2=.*|aria2=on|' $wp/AriaNG_update.sh
            fi
            clear && pannel
            ;;
        2)
            echo
            read -p $'\033[33m请输入AriaNG端口[默认随机]: \033[0m' Port
            [ -z "$Port" ] && Port=$(($RANDOM+37))
            echo
            sed -i '17s|listen.*|listen '$Port'\;|' $wp/nginx.conf
            pgrep nginx >/dev/null 2>&1 && systemctl restart ariang_nginx.service
            clear && pannel
            ;;
        3)
            echo
            read -p $'\033[33m请输入下载页面端口[默认随机]: \033[0m' dPort
            [ -z "$dPort" ] && dPort=$(($RANDOM+37))
            echo
            sed -i '27s|listen.*|listen '$dPort'\;|' $wp/nginx.conf
            pgrep nginx >/dev/null 2>&1 && systemctl restart ariang_nginx.service
            clear && pannel
            ;;
        4)
            read
            bash $wp/uninstall.sh
            clear && echo "AriaNG已卸载！" && exit 0
            ;;
        5)
            read
            rm -rf $wp/Download/*
            clear && pannel
            ;;
    esac
}

if grep -q "^##" /bin/ag;then
    public_ip=$(grep "^##" /bin/ag | grep -Eo '([0-9]{1,3}\.){3}[0-9]{1,3}')
else
    public_ip=$(curl -s http://ip-api.com/json | grep -Eo '([0-9]{1,3}\.){3}[0-9]{1,3}')
    sed -i '$a##'$public_ip'' /bin/ag
fi

clear ; pannel
clear
