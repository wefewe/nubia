#!/bin/bash
export PATH="/bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin:/usr/local/sbin"
wp="/usr/local/AriaNG"

systemctl kill ariang_caddy.service
systemctl kill ariang_aria2c.service
systemctl disable ariang_caddy.service > /dev/null 2>&1
systemctl disable ariang_aria2c.service > /dev/null 2>&1
rm -f /etc/systemd/system/ariang_caddy.service
rm -f /etc/systemd/system/ariang_aria2c.service

rm -rf $wp
rm -f /bin/ag

sed -i '/AriaNG_update\.sh/d' /etc/crontab
