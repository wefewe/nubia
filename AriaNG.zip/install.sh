#!/bin/bash
export PATH="/bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin:/usr/local/sbin"
wp="/usr/local/AriaNG"

RED="31m"      # Error message
GREEN="32m"    # Success message
YELLOW="33m"   # Warning message
BLUE="36m"     # Info message

colorEcho(){
    COLOR=$1
    echo -e "\033[${COLOR}${@:2}\033[0m"
    echo
}

cmd_need(){
    colorEcho $BLUE "正在安装 $1 ..."
    command -v yum >/dev/null 2>&1 && rpm -Uvh http://nginx.org/packages/centos/7/noarch/RPMS/nginx-release-centos-7-0.el7.ngx.noarch.rpm > /dev/null 2>&1
    $Installer install $1 -y > /dev/null 2>&1
    if [ "$?" != "0" ];then
        colorEcho $RED "命令安装失败！"
        exit 1
    fi
}

check_system(){
    Installer=$(command -v apt-get 2>/dev/null) || Installer=$(command -v yum 2>/dev/null) || colorEcho $RED "系统不支持，找不到apt-get或者yum！"
    SYSTEMCTL=$(command -v systemctl 2>/dev/null) || colorEcho $RED "系统不支持，找不到systemctl！"
    if [ "$(uname -m)" = "x86_64" ];then
        VDIS=64
    elif [ "$(uname -m)" = "i686" ] || [ "$(uname -m)" = "i386" ];then
        VDIS=32
    else
        colorEcho $RED "脚本仅支持X86架构设备！"
    fi
    if [ -z "$Installer" ] || [ -z "$SYSTEMCTL" ] || [ -z "$VDIS" ];then
        exit 1
    fi
}

install_ariang(){
    colorEcho $BLUE "正在开启AriaNG自启程序..."
    cat $wp/ariang_aria2c.service > /etc/systemd/system/ariang_aria2c.service
    cat $wp/ariang_nginx.service > /etc/systemd/system/ariang_nginx.service
    systemctl daemon-reload

    colorEcho $BLUE "正在安装AriaNG控制面板..."
    cat $wp/manage_pannel.sh > /bin/ag
    chmod +x /bin/ag
    
    colorEcho $BLUE "正在添加种子高速源..."
    bt_tracker=$(wget -qO- https://raw.githubusercontent.com/ngosang/trackerslist/master/trackers_best.txt | grep -v "^$" | tr "\n" "," | sed 's|,$||')
    [ ! -z "$bt_tracker" ] && sed -i "s|bt-tracker=.*|bt-tracker=$bt_tracker|" $wp/aria2.conf
    
    colorEcho $BLUE "正在启动种子高速源自动更新程序..."
    sed -i '/AriaNG_update\.sh/d' /etc/crontab
    echo "00 03 * * * $wp/AriaNG_update.sh" >> /etc/crontab
    
    chmod -R 777 $wp
}

set_port() {
    read -p $'\033[33m请设置AriaNG端口[默认随机]: \033[0m' Port
    [ -z "$Port" ] && Port=$(($RANDOM+37))
    echo
    sed -i '17s|listen.*|listen '$Port'\;|' $wp/nginx.conf
                
    read -p $'\033[33m请设置下载页面端口[默认随机]: \033[0m' dPort
    [ -z "$dPort" ] && dPort=$(($Port+1))
    echo
    sed -i '27s|listen.*|listen '$dPort'\;|' $wp/nginx.conf
}

main(){
    check_system
    cmd_need "unzip wget curl aria2 nginx"
    install_ariang
    set_port
    $SYSTEMCTL enable ariang_nginx.service >/dev/null 2>&1; $SYSTEMCTL start ariang_nginx.service
    $SYSTEMCTL enable ariang_aria2c.service >/dev/null 2>&1; $SYSTEMCTL start ariang_aria2c.service
    colorEcho $GREEN "AriaNG安装完成！输入ag可进入控制面板！"
}

main
