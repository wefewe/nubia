#!/bin/bash
export PATH="/bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin:/usr/local/sbin"
wp="/usr/local/AriaNG"

RED="31m"      # Error message
GREEN="32m"    # Success message
YELLOW="33m"   # Warning message
BLUE="36m"     # Info message

colorEcho(){
    COLOR=$1
    echo -e "\033[${COLOR}${@:2}\033[0m"
    echo
}

cmd_need(){
    colorEcho $BLUE "正在安装 $1 ..."
    if [ -z "$(command -v yum)" ];then
        apt-get install $1 -y
    else
        yum install $1 -y
    fi > /dev/null 2>&1
    if [ "$?" != "0" ];then
        colorEcho $RED "相关命令安装失败！"
        exit 1
    fi
}

install_ariang(){
    colorEcho $BLUE "正在开启AriaNG自启程序..."
    cat $wp/ariang_aria2c.service > /etc/systemd/system/ariang_aria2c.service
    cat $wp/ariang_caddy.service > /etc/systemd/system/ariang_caddy.service
    systemctl daemon-reload

    colorEcho $BLUE "正在安装AriaNG控制面板..."
    cat $wp/manage_pannel.sh > /bin/ag
    chmod +x /bin/ag
    
    colorEcho $BLUE "正在添加种子高速源..."
    bt_tracker=$(wget -qO- https://raw.githubusercontent.com/ngosang/trackerslist/master/trackers_best.txt | grep -v "^$" | tr "\n" "," | sed 's|,$||')
    [ ! -z "$bt_tracker" ] && sed -i "s|bt-tracker=.*|bt-tracker=$bt_tracker|" $wp/aria2.conf
    
    colorEcho $BLUE "正在启动种子高速源自动更新程序..."
    sed -i '/AriaNG_update\.sh/d' /etc/crontab
    echo "00 03 * * * $wp/AriaNG_update.sh" >> /etc/crontab
    
    chmod -R 777 $wp
}

set_port() {
    read -p $'\033[33m请设置AriaNG端口[默认随机]: \033[0m' Port
    [ -z "$Port" ] && Port=$(($RANDOM+37))
    echo
    sed -i '1s|0.0.0.0:.* |0.0.0.0:'$Port' |' $wp/caddy.conf
                
    read -p $'\033[33m请设置下载页面端口[默认随机]: \033[0m' dPort
    [ -z "$dPort" ] && dPort=$(($Port+1))
    echo
    sed -i '7s|0.0.0.0:.* |0.0.0.0:'$dPort' |' $wp/caddy.conf
}

main(){
    cmd_need "unzip wget curl"
    install_ariang
    set_port
    systemctl enable ariang_caddy.service >/dev/null 2>&1; systemctl start ariang_caddy.service
    systemctl enable ariang_aria2c.service >/dev/null 2>&1; systemctl start ariang_aria2c.service
    colorEcho $GREEN "AriaNG安装完成！输入ag可进入控制面板！"
}

main
