#!/system/bin/sh

jzdh=$1 && wp=${0%/*}

v2local_check() {
    echo
    [ -z "$(pgrep v2ray)" ] && v2ray_status="    ○⊃ V2Ray"
    [ ! -z "$(pgrep v2ray)" ] && v2ray_status="    ⊂● V2Ray"
    [ -z "$(pgrep pdnsd)" ] && pdnsd_status="   ○⊃ pdnsd"
    [ ! -z "$(pgrep pdnsd)" ] && pdnsd_status="   ⊂● pdnsd"
        [ "$udp_proxy" = "on" ] && [ -z "$(pgrep redsocks2)" ] && Redsocks2_status="   ○⊃ Redsocks2"
        [ "$udp_proxy" = "on" ] && [ ! -z "$(pgrep redsocks2)" ] && Redsocks2_status="   ⊂● Redsocks2"
    echo "${v2ray_status} ${pdnsd_status} ${Redsocks2_status}"
    if [ ! -z "${app_direct}" ];then
        echo
        for X in ${app_direct};do
            [ -z "$(echo "${X}" | grep -v '^[0-9]\+$')" ] && F=$X && X=$(grep "${X} " /data/system/packages.list | awk '{print $1}')
            [ ! -z "$(echo "${X}" | grep -v '^[0-9]\+$')" ] && F=$(grep "${X} " /data/system/packages.list | awk '{print $2}')
            [ ! -z "$F" ] && echo "    ${F} ${X}"
        done
        echo
    fi
}

v2local_stop() {
    killall v2ray pdnsd redsocks2
    ip rule del fwmark 0x33772 table 121
    ip route del local 0.0.0.0/0 dev lo table 121
    ip rule del fwmark 0x33771 uidrange 0-99999 table 120
    ip route del local 0.0.0.0/0 dev lo table 120
    clean_ip_rule=$(ip rule | grep "lookup 120" | awk '{print $7}')
    for Q in ${clean_ip_rule};do
        ip rule del fwmark 0x33771 uidrange $Q lookup 120
    done
    iptables -t nat -F VNO
    iptables -t nat -F VNP
    iptables -t mangle -F VMO
    iptables -t mangle -F VMP
    iptables -t nat -D OUTPUT -j VNO
    iptables -t nat -D PREROUTING -j VNP
    iptables -t mangle -D OUTPUT -j VMO
    iptables -t mangle -D PREROUTING -j VMP
    iptables -t nat -X VNO
    iptables -t nat -X VNP
    iptables -t mangle -X VMO
    iptables -t mangle -X VMP
} > /dev/null 2>&1

pre_v2local() {
    ${wp}/bin/v2ray --help > /dev/null 2>&1
    [ "$?" != "2" ] && echo && echo " 请赋予文件夹及其子文件777权限后重试" && exit 0

    cd $wp && source $(pwd)/v2ray.txt
    export PATH=${PATH}:$(pwd)/bin
    wp_if_system=$(busybox echo "$(pwd)" | busybox grep -Eo "^/system")
    [ "$wp_if_system" = "/system" ] && busybox mount -o remount,rw /system
    busybox ln -s $(pwd)/bin/busybox $(pwd)/bin/awk > /dev/null 2>&1
    busybox ln -s $(pwd)/bin/busybox $(pwd)/bin/echo > /dev/null 2>&1
    busybox ln -s $(pwd)/bin/busybox $(pwd)/bin/grep > /dev/null 2>&1
    busybox ln -s $(pwd)/bin/busybox $(pwd)/bin/sed > /dev/null 2>&1
    busybox ln -s $(pwd)/bin/busybox $(pwd)/bin/killall > /dev/null 2>&1
    busybox ln -s $(pwd)/bin/busybox $(pwd)/bin/ls > /dev/null 2>&1
    busybox ln -s $(pwd)/bin/busybox $(pwd)/bin/sort > /dev/null 2>&1
    busybox ln -s $(pwd)/bin/busybox $(pwd)/bin/ifconfig > /dev/null 2>&1
    busybox ln -s $(pwd)/bin/busybox $(pwd)/bin/wc > /dev/null 2>&1
    busybox ln -s $(pwd)/bin/busybox $(pwd)/bin/chmod > /dev/null 2>&1
    busybox ln -s $(pwd)/bin/busybox $(pwd)/bin/rm > /dev/null 2>&1
    busybox ln -s $(pwd)/bin/busybox $(pwd)/bin/pgrep > /dev/null 2>&1
    busybox ln -s $(pwd)/bin/busybox $(pwd)/bin/nohup > /dev/null 2>&1
    busybox ln -s $(pwd)/bin/busybox $(pwd)/bin/sleep > /dev/null 2>&1
    special_ip='10.0.0.172/32,10.0.0.200/32,0/8,10/8,127/8,192.168/16,255.255/8,240/4,224/3,169.254/16,100.64/10,172.16/12'
    chmod -R 777 $(pwd)
}

vim_config() {
    UUID=$(echo "$v2ray" | awk '{print $2}')
    address=$(echo "$v2ray" | awk '{print $1}' | awk -F ":" '{print $1}')
    Host_line=$(($(grep -n '"Host"' $(pwd)/bin/config.json | awk -F ":" '{print $1}')+1))
    Path_line=$(($(grep -n '"path"' $(pwd)/bin/config.json | awk -F ":" '{print $1}')+1))
    for E in config.json break_copyright.json;do
        sed -i 's|address.*|address": "'$address'",|g' $(pwd)/bin/${E}
        sed -i 's|^          "port.*|          "port": '$port',|g' $(pwd)/bin/${E}
        sed -i 's|"id".*|"id": "'$UUID'",|g' $(pwd)/bin/${E}
        sed -i 's|"alterId".*|"alterId": '$alterId',|g' $(pwd)/bin/${E}
        sed -i 's|"security".*|"security": "'$security'"|g' $(pwd)/bin/${E}
        sed -i ''$Path_line's|.*|              "'$Path'"|g' $(pwd)/bin/${E}
        sed -i ''$Host_line's|.*|                "'$Host'"|g' $(pwd)/bin/${E}
    done
}

v2local_bin_start() {
    v2local_wp=$(pwd | sed 's|/| /|g' | sed 's|^ ||')
    for F in ${v2local_wp};do
        M="${M}$F"
        v2local_wp_r=$(ls -ld "$M" | awk '{print $1}' | sed 's|.*\(...\)|\1|' | grep 'r')
        v2local_wp_x=$(ls -ld "$M" | awk '{print $1}' | sed 's|.*\(...\)|\1|' | grep 'x')
        [ -z "$v2local_wp_r" ] && echo "o-r $M" >> $(pwd)/bin/chmod.txt
        [ -z "$v2local_wp_x" ] && echo "o-x $M" >> $(pwd)/bin/chmod.txt
        chmod o+rx $M
    done
    
    pdnsd_cache_wp=$(grep 'cache_dir' $(pwd)/bin/pdnsd.conf | awk -F '"' '{print $2}' | awk -F '"' '{print $1}')
    [ "$pdnsd_cache_wp" != "$(pwd)/bin" ] && sed -i 's|'$pdnsd_cache_wp'|'$(pwd)/bin'|' $(pwd)/bin/pdnsd.conf
    nohup pdnsd -c $(pwd)/bin/pdnsd.conf &
    sleep 0.5
    [ "$break_copyright" != "on" ] && nohup su - 3004 -c "$(pwd)/bin/v2ray -config $(pwd)/bin/config.json" &
    [ "$break_copyright" = "on" ] && nohup su - 3004 -c "$(pwd)/bin/v2ray -config $(pwd)/bin/break_copyright.json" &
    sleep 0.5
    [ -z "$(pgrep redsocks2)" ] && nohup redsocks2 -c $(pwd)/bin/redsocks2.conf &
    
    chmod_txt_line=$(wc -l $(pwd)/bin/chmod.txt | grep -Eo '^[0-9]*')
    var=1
    while [ "var" -le "$chmod_txt_line" ];do
        chmod_bak=$(sed -n ''$var'p' $(pwd)/bin/chmod.txt)
        chmod ${chmod_bak}
        var=$(($var+1))
    done
    rm -f $(pwd)/bin/chmod.txt
    [ "$wp_if_system" = "/system" ] && mount -o remount,ro /system
} > /dev/null 2>&1

add_iptables() {
    iptables -t nat -N VNO
    iptables -t nat -I OUTPUT -j VNO
    iptables -t mangle -N VMO
    iptables -t mangle -N VMP
    iptables -t mangle -I OUTPUT -j VMO
    iptables -t mangle -I PREROUTING -j VMP
}

app_direct() {
    for X in ${app_direct};do
        [ -z "$(echo "${X}" | grep -v '^[0-9]\+$')" ] && F="$X"
        [ ! -z "$(echo "${X}" | grep -v '^[0-9]\+$')" ] && F=$(grep "${X} " /data/system/packages.list | awk '{print $2}')
        [ ! -z "$F" ] && G="${G} $F"
    done
    ip_app_away=$(echo "$G" | sed 's|^ ||' | tr " " "\n" | sort)
    ip_start_num="0"
    for X in ${ip_app_away};do
        [ ! -z "$X" ] && F=$((${X}-1))
        ip rule add fwmark 0x33771 uidrange "$ip_start_num"-"$F" table 120
        [ ! -z "$X" ] && ip_start_num=$((${X}+1))
    done
    [ ! -z "$X" ] && ip rule add fwmark 0x33771 uidrange "$ip_start_num"-99999 table 120
}

udp_iptables() {
    ip route add local 0.0.0.0/0 dev lo table 121
    ip rule add fwmark 0x33772 table 121
    iptables -t mangle -A VMO -p udp ! --dport 53 -j MARK --set-mark 0x33772
    iptables -t mangle -A VMP -p udp ! --dport 53 -j TPROXY --on-port 33774 --tproxy-mark 0x33772
    [ "$?" != "0" ] && echo && echo "  你的手机不支持TPROXY模块，请关掉UDP代理" && (v2local_stop;exit 0)
}

necessary_iptables() {
    ip route add local 0.0.0.0/0 dev lo table 120
    [ -z "$app_direct" ] && ip rule add fwmark 0x33771 uidrange 0-99999 table 120
    [ ! -z "$app_direct" ] && app_direct
    iptables -t mangle -I VMO -d "$special_ip" -j ACCEPT
    iptables -t mangle -I VMP -d "$special_ip" -j ACCEPT
    iptables -t mangle -I VMO -o lo -j ACCEPT
    iptables -t mangle -I VMP -o lo -j ACCEPT
    iptables -t mangle -I VMO -p udp --dport 53 -j MARK --set-mark 0x33771
    iptables -t mangle -I VMO ! -o wlan+ ! -p icmp -m state --state INVALID -j DROP
    iptables -t mangle -I VMO ! -o wlan+ -p icmp -j DROP
    [ "$wifi_proxy" = "off" ] && iptables -t mangle -I VMO -o wlan+ -j ACCEPT
    if [ -z "$network_whitelist" ];then
        iptables -t mangle -A VMO -p tcp -d $address --dport $port -m owner --uid-owner 3004 -j ACCEPT
        iptables -t mangle -A VMO -p tcp --dport 443 -m owner --uid-owner 3004 -j ACCEPT
        [ "$break_copyright" = "on" ] && iptables -t mangle -A VMO -p tcp --dport 80 -m owner --uid-owner 3004 -j ACCEPT
    else
        iptables -t mangle -A VMO -p tcp -s "${network_whitelist}/16" -d $address --dport $port -m owner --uid-owner 3004 -j ACCEPT
        iptables -t mangle -A VMO -p tcp -s "${network_whitelist}/16" --dport 443 -m owner --uid-owner 3004 -j ACCEPT
        [ "$break_copyright" = "on" ] && iptables -t mangle -A VMO -p tcp -s "${network_whitelist}/16" --dport 80 -m owner --uid-owner 3004 -j ACCEPT
    fi
    iptables -t mangle -A VMO -p tcp -j MARK --set-mark 0x33771
    iptables -t nat -A VNO -p udp --dport 53 -m mark --mark 0x33771 -j REDIRECT --to 53
    iptables -t nat -A VNO -p tcp -m mark --mark 0x33771 -j REDIRECT --to 33771
}

hot_tcp_iptables() {
    iptables -t nat -N VNP
    iptables -t nat -I PREROUTING -j VNP
    iptables -t nat -A VNP -p udp --dport 53 -m mark --mark 0x33771 -j REDIRECT --to 53
    iptables -t nat -A VNP -p tcp -m mark --mark 0x33771 -j REDIRECT --to 33771
    iptables -t mangle -A VMP -p tcp -j MARK --set-mark 0x33771
    iptables -t mangle -I VMP -p udp --dport 53 -j MARK --set-mark 0x33771
}

control_network() {
    network_ip=$(ifconfig $network | awk '{print $2}' | grep -Eo "[0-9]*\.[0-9]*\.[0-9]*\.[0-9]*")
    judge_network_ip=$(echo $network_ip | grep "^$network_whitelist")
    echo "  当前IP：$network_ip" && echo
    while [ ! -z "$network_ip" -a -z "$judge_network_ip" ];do
        settings put global airplane_mode_on 1
        am broadcast -a android.intent.action.AIRPLANE_MODE --ez state true > /dev/null 2>&1
        sleep $plane_stop
        settings put global airplane_mode_on 0
        am broadcast -a android.intent.action.AIRPLANE_MODE --ez state false > /dev/null 2>&1
        sleep $plane_wait
        network_ip=$(ifconfig $network | awk '{print $2}' | grep -Eo "[0-9]*\.[0-9]*\.[0-9]*\.[0-9]*")
        judge_network_ip_ip=$(echo $network_ip | grep "^$network_whitelist")
        echo "  当前IP：$network_ip" && echo
    done
}

main() {
    #检查权限，定义变量
    pre_v2local
    if [ -z "$jzdh" ];then
        #停止v2local
        v2local_stop
        #编辑配置文件
        vim_config
        #启动相关模块
        v2local_bin_start
        #创建初始规则
        add_iptables
        #大部分udp规则
        [ "$udp_proxy" = "on" ] && udp_iptables
        #热点规则
        [ "$hot_tcp_proxy" = "on" ] && hot_tcp_iptables
        #tcp主规则
        necessary_iptables
        #获取v2local运行状态
        v2local_check
        #调内网
        [ ! -z "$network_whitelist" ] && control_network
    elif [ "$jzdh" = "stop" ];then
        #停止v2local
        v2local_stop
        #获取v2local运行状态
        v2local_check
    elif [ "$jzdh" = "check" ];then
        #获取v2local运行状态
        v2local_check
    fi
    #删除部分文件
    rm -f $(pwd)/*.bak
    rm -f $(pwd)/bin/*.bak
}

main
