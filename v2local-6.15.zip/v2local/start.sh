#!/system/bin/sh

jzdh=$1 && wp=${0%/*}

v2local_check() {
    echo
    [ "$(pgrep v2ray)" = "" ] && v2ray_status="    ○⊃ V2Ray"
    [ "$(pgrep v2ray)" != "" ] && v2ray_status="    ⊂● V2Ray"
    [ "$(pgrep pdnsd)" = "" ] && pdnsd_status="   ○⊃ pdnsd"
    [ "$(pgrep pdnsd)" != "" ] && pdnsd_status="   ⊂● pdnsd"
    [ "$udp_proxy" = "on" ] && [ "$(pgrep redsocks2)" = "" ] && Redsocks2_status="   ○⊃ Redsocks2"
    [ "$udp_proxy" = "on" ] && [ "$(pgrep redsocks2)" != "" ] && Redsocks2_status="   ⊂● Redsocks2"
    echo "${v2ray_status} ${pdnsd_status} ${Redsocks2_status}"
    if [ ! -z "${app_direct}" ];then
        echo
        for X in ${app_direct};do
            [ "$(echo "${X}" | grep -v '^[0-9]\+$')" = "" ] && F=$X && X=$(grep "${X} " /data/system/packages.list | awk '{print $1}')
            [ "$(echo "${X}" | grep -v '^[0-9]\+$')" != "" ] && F=$(grep "${X} " /data/system/packages.list | awk '{print $2}')
            [ ! -z "$F" ] && echo "    ${F} ${X}"
        done
        echo
    fi
    if [ ! -z "${wifi_direct}" -a "$wifi_direct" != "all" ];then
        for X in ${wifi_direct};do
            [ "$(echo "${X}" | grep -v '^[0-9]\+$')" = "" ] && F=$X && X=$(grep "${X} " /data/system/packages.list | awk '{print $1}')
            [ "$(echo "${X}" | grep -v '^[0-9]\+$')" != "" ] && F=$(grep "${X} " /data/system/packages.list | awk '{print $2}')
            [ ! -z "$F" ] && echo "    ${F} ${X}"
        done
        echo
    fi
}

v2local_stop() {
    [ -z "$1" ] && killall pdnsd redsocks2
    killall v2ray
    ip rule del fwmark 0x33772 table 121
    ip route del local 0.0.0.0/0 dev lo table 121
    iptables -t nat -D OUTPUT -j VNO	
    iptables -t nat -D PREROUTING -j VNP
    iptables -t mangle -D OUTPUT -j VMO
    iptables -t mangle -D PREROUTING -j VMP
    iptables -t nat -F VNO
    iptables -t nat -F VNP
    iptables -t mangle -F VMO
    iptables -t mangle -F VMP
    iptables -t nat -X VNO
    iptables -t nat -X VNP
    iptables -t mangle -X VMO
    iptables -t mangle -X VMP
} > /dev/null 2>&1

pre_v2local() {
    ${wp}/bin/busybox > /dev/null 2>&1
    [ "$?" != "0" ] && echo && echo " 请赋予文件夹及其子文件0777权限后重试" && exit 0

    cd $wp && source $(pwd)/v2ray.txt
    export PATH=$(pwd)/bin:$PATH
    if_system=$(busybox echo "$(pwd)" | busybox grep -Eo "^/system")
    [ "$if_system" = "/system" ] && busybox mount -o remount,rw /system
    busybox ln -s $(pwd)/bin/busybox $(pwd)/bin/awk  > /dev/null 2>&1 && \
    busybox ln -s $(pwd)/bin/busybox $(pwd)/bin/echo && \
    busybox ln -s $(pwd)/bin/busybox $(pwd)/bin/grep && \
    busybox ln -s $(pwd)/bin/busybox $(pwd)/bin/sed && \
    busybox ln -s $(pwd)/bin/busybox $(pwd)/bin/killall && \
    busybox ln -s $(pwd)/bin/busybox $(pwd)/bin/ip && \
    busybox ln -s $(pwd)/bin/busybox $(pwd)/bin/rm && \
    busybox ln -s $(pwd)/bin/busybox $(pwd)/bin/pgrep && \
    busybox ln -s $(pwd)/bin/busybox $(pwd)/bin/nohup && \
    busybox ln -s $(pwd)/bin/busybox $(pwd)/bin/sleep
    UUID=$(echo "$v2ray" | awk '{print $2}')
    port=$(echo "$v2ray" | awk '{print $1}' | awk -F ":" '{print $2}')
    address=$(echo "$v2ray" | awk '{print $1}' | awk -F ":" '{print $1}')
    special_ip='10.0.0.172/32,10.0.0.200/32,0/8,10/8,127/8,192.168/16,255.255/8,240/4,224/3,169.254/16,100.64/10,172.16/12'
    chmod -R 0777 $(pwd)
    Host_line=$(($(grep -n '"Host"' $(pwd)/bin/config.json | awk -F ":" '{print $1}')+1))
    Path_line=$(($(grep -n '"path"' $(pwd)/bin/config.json | awk -F ":" '{print $1}')+1))
    pdnsd_cache_wp=$(grep 'cache_dir' $(pwd)/bin/pdnsd.conf | awk -F '"' '{print $2}' | awk -F '"' '{print $1}')
}

vim_config() {
    for E in config break_copyright;do
        sed -i 's|address.*|address": "'$address'",|g' $(pwd)/bin/${E}.json
        sed -i 's|^          "port.*|          "port": '$port',|g' $(pwd)/bin/${E}.json
        sed -i 's|"id".*|"id": "'$UUID'",|g' $(pwd)/bin/${E}.json
        sed -i 's|"alterId".*|"alterId": '$alterId',|g' $(pwd)/bin/${E}.json
        sed -i 's|"security".*|"security": "'$security'"|g' $(pwd)/bin/${E}.json
        sed -i ''$Path_line's|.*|              "'$Path'"|g' $(pwd)/bin/${E}.json
        sed -i ''$Host_line's|.*|                "'$Host'"|g' $(pwd)/bin/${E}.json
    done
}

v2local_bin_start() {
    [ "$pdnsd_cache_wp" != "$(pwd)/bin" ] && sed -i 's|'$pdnsd_cache_wp'|'$(pwd)/bin'|' $(pwd)/bin/pdnsd.conf
    [ "$(pgrep pdnsd)" = "" ] && nohup pdnsd -c $(pwd)/bin/pdnsd.conf &
    sleep 0.5
    [ "$break_copyright" != "on" ] && v2ray -config $(pwd)/bin/config.json &
    [ "$break_copyright" = "on" ] && v2ray -config $(pwd)/bin/break_copyright.json &
    sleep 0.5
    [ "$udp_proxy" = "on" ] && [ -z "$(pgrep redsocks2)" ] && redsocks2 -c $(pwd)/bin/redsocks2.conf &
} > /dev/null 2>&1

add_iptables() {
    iptables -t nat -N VNO
    iptables -t nat -I OUTPUT -j VNO
    iptables -t mangle -N VMO
    iptables -t mangle -N VMP
    iptables -t mangle -I OUTPUT -j VMO
    iptables -t mangle -I PREROUTING -j VMP
}

app_direct() {
    if [ ! -z "$app_direct" ];then
        for X in ${app_direct};do
            [ "$(echo "${X}" | grep -v '^[0-9]\+$')" = "" ] && F="$X"
            [ "$(echo "${X}" | grep -v '^[0-9]\+$')" != "" ] && F=$(grep "${X}" /data/system/packages.list | awk '{print $2}')
            [ ! -z "$F" ] && iptables -t mangle -A VMO -m owner --uid-owner $F -j ACCEPT
            [ ! -z "$F" ] && iptables -t nat -A VNO -m owner --uid-owner $F -j ACCEPT
        done
    fi
}

udp_iptables() {
    if [ "$udp_proxy" = "on" ];then
        ip rule add fwmark 0x33772 table 121
        ip route add local 0.0.0.0/0 dev lo table 121
        for A in "${special_ip},${address}/32";do
            iptables -t mangle -A VMO -d $A -j ACCEPT
            iptables -t mangle -A VMP -d $A -j ACCEPT
        done
        iptables -t mangle -A VMO -p udp ! --dport 53 -j MARK --set-mark 0x33772
        iptables -t mangle -A VMP -p udp ! --dport 53 -j TPROXY --on-port 33774 --tproxy-mark 0x33772
    fi
}

necessary_iptables() {
    iptables -t mangle -I VMO ! -o wlan+ -p tcp -m state --state INVALID -j DROP
    iptables -t mangle -I VMO ! -o wlan+ -p udp -m state --state INVALID -j DROP
    iptables -t mangle -I VMO ! -o wlan+ -p icmp -j DROP
    iptables -t nat -A VNO -p tcp -d "${special_ip}" -j ACCEPT
    [ "$break_copyright" = "on" ] && iptables -t nat -A VNO -p tcp --dport 80 -m owner --uid-owner root -j ACCEPT
    iptables -t nat -A VNO -p tcp -d $address --dport $port -j ACCEPT
    iptables -t nat -A VNO -p tcp --dport 443 -m owner --uid-owner root -j ACCEPT
    iptables -t nat -A VNO -p udp --dport 53 -j REDIRECT --to 33773
    iptables -t nat -A VNO -p tcp -j REDIRECT --to 33771
}

hot_tcp_iptables() {
    if [ "$hot_tcp_proxy" = "on" ];then
        iptables -t nat -N VNP
        iptables -t nat -I PREROUTING -j VNP
        iptables -t nat -A VNP -p tcp ! -d 192.168/16 -j REDIRECT --to 33771
        iptables -t nat -A VNP -p udp --dport 53 -j REDIRECT --to 33773
    fi
}

wifi_proxy() {
    if [ "$wifi_direct" = "all" ];then
        iptables -t nat -A VNO -p tcp -o wlan+ -j ACCEPT
        iptables -t mangle -A VMO -p udp -o wlan+ -j ACCEPT
    elif [ ! -z "$wifi_direct" ];then
        for X in ${wifi_direct};do
            [ "$(echo "${X}" | grep -v '^[0-9]\+$')" = "" ] && F="$X"
            [ "$(echo "${X}" | grep -v '^[0-9]\+$')" != "" ] && F=$(grep "${X} " /data/system/packages.list | awk '{print $2}')
            [ ! -z "$F" ] && iptables -t mangle -A VMO -p udp -o wlan+ -m owner --uid-owner $F -j ACCEPT
            [ ! -z "$F" ] && iptables -t nat -A VNO -p tcp -o wlan+ -m owner --uid-owner $F -j ACCEPT
        done
    fi
}

main() {
    #检查权限，定义变量
    pre_v2local
    if [ "$jzdh" = "" ];then
        #停止v2local
        v2local_stop 1
        #编辑配置文件
        vim_config
        #启动相关模块
        v2local_bin_start
        #创建初始规则
        add_iptables
        #应用放行
        app_direct
        #wifi应用放行
        wifi_proxy
        #大部分udp规则
        udp_iptables
        #热点规则
        hot_tcp_iptables
        #tcp主规则
        necessary_iptables
        #获取v2local运行状态
        v2local_check
    elif [ "$jzdh" = "stop" ];then
        #停止v2local
        v2local_stop
        #获取v2local运行状态
        v2local_check
    elif [ "$jzdh" = "check" ];then
        #获取v2local运行状态
        v2local_check
    fi
    #删除部分文件
    rm -f $(pwd)/*bak;rm -f $(pwd)/bin/*bak
    #system读写还原
    [ "$if_system" = "/system" ] && mount -o remount,ro /system
}

main
