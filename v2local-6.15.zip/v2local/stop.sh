#!/system/bin/sh

cd ${0%/*} && ./start.sh stop